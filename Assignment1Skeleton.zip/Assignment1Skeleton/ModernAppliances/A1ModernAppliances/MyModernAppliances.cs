﻿using ModernAppliances.Entities;
using ModernAppliances.Entities.Abstract;
using ModernAppliances.Helpers;

namespace ModernAppliances
{
    /// <summary>
    /// Manager class for Modern Appliances
    /// </summary>
    /// <remarks>Author: </remarks>
    /// <remarks>Date: </remarks>
    internal class MyModernAppliances : ModernAppliances
    {
        /// <summary>
        /// Option 1: Performs a checkout
        /// </summary>
        public override void Checkout()
        {
            // Write "Enter the item number of an appliance: "
            Console.WriteLine("Enter the item number of an appliance: ");
            // Create long variable to hold item number
            string itemNumber = Console.ReadLine();
            // Get user input as string and assign to variable.
            // Convert user input from string to long and store as item number variable.
            long.TryParse(itemNumber, out long ItemNumber);
            // Create 'foundAppliance' variable to hold appliance with item number
            // Assign null to foundAppliance (foundAppliance may need to be set as nullable)
            Appliance foundAppliance = null;
            // Loop through Appliances
            // Test appliance item number equals entered item number
            // Assign appliance in list to foundAppliance variable
            foreach (var appliance in Appliances)
            {
                if (appliance.ItemNumber == ItemNumber)
                {
                    foundAppliance = appliance;

                    break;
                }
            }

            if (foundAppliance != null && foundAppliance.Quantity > 0)
            {
                Console.WriteLine(foundAppliance.Quantity);
                Console.WriteLine("Appliance \"" + itemNumber + "\" has been checked out.");
                foundAppliance.Quantity--;
                Console.WriteLine(foundAppliance.Quantity);

            }
            else if (foundAppliance != null && foundAppliance.Quantity == 0)
            {
                Console.WriteLine("The appliance is not available to be checked out.");
            }
            else
            {
                Console.WriteLine("No appliances found with that item number.");
            }


        }



        // Break out of loop (since we found what need to)

        // Test appliance was not found (foundAppliance is null)
        // Write "No appliances found with that item number."

        // Otherwise (appliance was found)
        // Test found appliance is available
        // Checkout found appliance

        // Write "Appliance has been checked out."
        // Otherwise (appliance isn't available)
        // Write "The appliance is not available to be checked out."


        /// <summary>
        /// Option 2: Finds appliances
        /// </summary>
        public override void Find()
        {
            // Write "Enter brand to search for:"
            Console.WriteLine("Enter brand to search for:");
            // Create string variable to hold entered brand
            // Get user input as string and assign to variable.
            string Brand = Console.ReadLine();
            // Create list to hold found Appliance objects

            // Iterate through loaded appliances
            // Test current appliance brand matches what user entered
            // Add current appliance in list to found list
            Console.WriteLine("\nMatching Appliances:\n");
            bool flag = false;
            foreach (Appliance app in Appliances)
            {
                if (app.Brand.ToLower() == Brand.ToLower())
                {
                    Console.WriteLine(app);
                    flag = true;
                }
            }
            if (flag == false)
            {
                Console.WriteLine("No appliance with the brand name found.");
            }

            // Display found appliances
            // DisplayAppliancesFromList(found, 0);
        }

        /// <summary>
        /// Displays Refridgerators
        /// </summary>
        public override void DisplayRefrigerators()
        {
            // Write "Possible options:"

            // Write "0 - Any"
            // Write "2 - Double doors"
            // Write "3 - Three doors"
            // Write "4 - Four doors"
            Console.WriteLine("0 - Any\n2 - Double doors\n3 - Three doors\n4 - Four doors\n");
            // Write "Enter number of doors: "
            Console.WriteLine("Enter number of doors:");
            // Create variable to hold entered number of doors
            string EnteredNumber = Console.ReadLine();
            // Get user input as string and assign to variable
            // Convert user input from string to int and store as number of doors variable.
            int num = int.Parse(EnteredNumber);
            // Create list to hold found Appliance objects
            // Iterate/loop through Appliances
            // Test that current appliance is a refrigerator
            // Down cast Appliance to Refrigerator
            // Refrigerator refrigerator = (Refrigerator) appliance;
            List<Appliance> foundRefrigerators = new List<Appliance>();
            foreach (var appliance in Appliances)
            {
                if (appliance is Refrigerator)
                {
                    Refrigerator refrigerator = (Refrigerator)appliance;
                    if (num == 0 || refrigerator.Doors == num)
                    {
                        foundRefrigerators.Add(refrigerator);
                    }
                }

            }
            // Test user entered 0 or refrigerator doors equals what user entered.
            // Add current appliance in list to found list

            // Display found appliances
            // DisplayAppliancesFromList(found, 0);
            if (foundRefrigerators.Count > 0)
            {
                Console.WriteLine("Found Refrigerators:");
                foreach (var refrigerator in foundRefrigerators)
                {
                    Console.WriteLine(refrigerator);
                }
            }
            else
            {
                Console.WriteLine("No refrigerators found with the specified number of doors.");
            }




        }
        /// <summary>
        /// Displays Vacuums
        /// </summary>
        /// <param name="grade">Grade of vacuum to find (or null for any grade)</param>
        /// <param name="voltage">Vacuum voltage (or 0 for any voltage)</param>
        public override void DisplayVacuums()
        {
            // Write "Possible options:"

            // Write "0 - Any"
            // Write "1 - Residential"
            // Write "2 - Commercial"
            Console.WriteLine("0 - Any\n1 - Residential\n2 - Commercial");
            // Write "Enter grade:"
            Console.WriteLine("Enter grade: ");
            // Get user input as string and assign to variable
            string UGreade = Console.ReadLine();
            // Create grade variable to hold grade to find (Any, Residential, or Commercial)
            int VacumeGrades = int.Parse(UGreade);
            // Test input is "0"
            // Assign "Any" to grade
            // Test input is "1"
            // Assign "Residential" to grade
            // Test input is "2"
            // Assign "Commercial" to grade
            // Otherwise (input is something else)
            // Write "Invalid option."
            string Grades = "";
            if (VacumeGrades == 0)
            {
                Grades = "Any";
            }
            else if (VacumeGrades == 1)
            {
                Grades = "Residential";
            }
            else if (VacumeGrades == 2)
            {
                Grades = "Commercial";
            }
            else
            {
                Console.WriteLine("Invalid option.");
                return;
            }

            // Return to calling (previous) method
            // return;

            // Write "Possible options:"

            // Write "0 - Any"
            // Write "1 - 18 Volt"
            // Write "2 - 24 Volt"
            Console.WriteLine("Enter battery voltage value. 18 V (1) or 24 V (2)");
            // Write "Enter voltage:"
            string y = Console.ReadLine();
            // Get user input as string
            // Create variable to hold voltage
            int voltage = int.Parse(y);
            // Test input is "0"
            // Assign 0 to voltage
            // Test input is "1"
            // Assign 18 to voltage
            // Test input is "2"
            // Assign 24 to voltage
            // Otherwise
            // Write "Invalid option."
            // Return to calling (previous) method
            // return;

            // Create found variable to hold list of found appliances.

            // Loop through Appliances
            // Check if current appliance is vacuum
            // Down cast current Appliance to Vacuum object
            // Vacuum vacuum = (Vacuum)appliance;
            if (voltage == 0)
            {
                voltage = 0;
            }
            else if (voltage == 1)
            {
                voltage = 18;
            }
            else if (voltage == 2)
            {
                voltage = 24;
            }
            else
            {
                Console.WriteLine("Invalid option.");
                return;
            }
            Console.WriteLine("Matching Vacuums:");

            foreach (Appliance appliance in Appliances)
            {
                if (appliance is Vacuum vacuum)
                {
                    if ((Grades == "Any" || vacuum.Grade == Grades) && (voltage == 0 || vacuum.BatteryVoltage == voltage))
                    {
                        Console.WriteLine(vacuum);
                    }
                }
            }

        }



        // Test grade is "Any" or grade is equal to current vacuum grade and voltage is 0 or voltage is equal to current vacuum voltage
        // Add current appliance in list to found list

        // Display found appliances
        // DisplayAppliancesFromList(found, 0);


        /// <summary>
        /// Displays microwaves
        /// </summary>
        public override void DisplayMicrowaves()
        {
            // Write "Possible options:"

            Console.WriteLine("Possible options:");

            // Write "0 - Any"
            // Write "1 - Kitchen"
            // Write "2 - Work site"

            Console.WriteLine("0 - Any\n1 - Kitchen\n2 - Work site");



            // Write "Enter room type:"

            Console.WriteLine("Enter room type:");

            // Get user input as string and assign to variable
            string roomCheck = Console.ReadLine();
            // Create character variable that holds room type
            char roomType;
            // Test input is "0"
            // Assign 'A' to room type variable
            if (roomCheck == "0")
            {
                roomType = 'A';
            }
            // Test input is "1"
            // Assign 'K' to room type variable

            else if (roomCheck == "1")
            {
                roomType = 'K';
            }
            // Test input is "2"
            // Assign 'W' to room type variable
            else if (roomCheck == "2")
            {
                roomType = 'W';
            }
            // Otherwise (input is something else)
            // Write "Invalid option."
            else
            {
                Console.WriteLine("Invalid option.");
                return;
            }
            // Return to calling method
            // return;

            // Create variable that holds list of 'found' appliances
            List<Appliance> found = new List<Appliance>();

            // Loop through Appliances



            // Test current appliance is Microwave
            // Down cast Appliance to Microwave

            // Test room type equals 'A' or microwave room type
            // Add current appliance in list to found list

            foreach (Appliance appliance in Appliances)
            {
                if (appliance is Microwave microwave)
                {
                    if (microwave.RoomType == roomType || microwave.RoomType == 'A')
                    {
                        found.Add(microwave);
                    }
                }

            }

            // Display found appliances
            // DisplayAppliancesFromList(found, 0);

            if (found.Count > 0)
            {
                Console.WriteLine("Found Microwaves:");
                foreach (var microwave in found)
                {
                    Console.WriteLine(microwave);
                }
            }
            else
            {
                Console.WriteLine("No microwaves found with the specified room type.");
            }
        }

        /// <summary>
        /// Displays dishwashers
        /// </summary>
        public override void DisplayDishwashers()
        {
            // Write "Possible options:"

            // Write "0 - Any"
            // Write "1 - Quietest"
            // Write "2 - Quieter"
            // Write "3 - Quiet"
            // Write "4 - Moderate"

            // Write "Enter sound rating:"

            Console.WriteLine("Possible options:" +
                "\n0 - Any" +
                "\n1 - Quietest" +
                "\n2 - Quieter" +
                "\n3 - Quiet" +
                "\n4 - Moderate" +
                "\nEnter sound rating:");

            // Get user input as string and assign to variable

            string soundCheck = Console.ReadLine();

            // Create variable that holds sound rating

            string soundRating;

            // Test input is "0"
            // Assign "Any" to sound rating variable

            if (soundCheck == "0")
            {
                soundRating = "A";
            }

            // Test input is "1"
            // Assign "Qt" to sound rating variable

            else if (soundCheck == "1")
            {
                soundRating = "Qt";
            }
            // Test input is "2"
            // Assign "Qr" to sound rating variable
            else if (soundCheck == "2")
            {
                soundRating = "Qr";
            }
            // Test input is "3"
            // Assign "Qu" to sound rating variable

            else if (soundCheck == "3")
            {
                soundRating = "Qu";
            }
            // Test input is "4"
            // Assign "M" to sound rating variable

            else if (soundCheck == "4")
            {
                soundRating = "M";
            }

            // Otherwise (input is something else)
            // Write "Invalid option."
            // Return to calling method

            else
            {
                Console.WriteLine("Invalid option.");
                return;
            }


            // Create variable that holds list of found appliances

            List<Appliance> found = new List<Appliance>();

            // Loop through Appliances
            // Test if current appliance is dishwasher
            // Down cast current Appliance to Dishwasher

            foreach (Appliance appliance in Appliances)
            {
                if (appliance is Dishwasher dishwasher)
                {
                    if (soundRating == "A" || dishwasher.SoundRating == soundRating)
                    {
                        found.Add(dishwasher);
                    }
                }
            }

            // Test sound rating is "Any" or equals soundrating for current dishwasher
            // Add current appliance in list to found list

            // Display found appliances (up to max. number inputted)
            // DisplayAppliancesFromList(found, 0);

            if (found.Count > 0)
            {
                Console.WriteLine("Found Dishwashers:");
                foreach (var dishwasher in found)
                {
                    Console.WriteLine(dishwasher);
                }
            }
            else
            {
                Console.WriteLine("No dishwashers found with the specified sound rating.");
            }
        }

        /// <summary>
        /// Generates random list of appliances
        /// </summary>
        public override void RandomList()
        {
            // Write "Appliance Types"

            // Write "0 - Any"
            // Write "1 – Refrigerators"
            // Write "2 – Vacuums"
            // Write "3 – Microwaves"
            // Write "4 – Dishwashers"

            // Write "Enter type of appliance:"

            /*
            Console.WriteLine("Appliance Types" +
                "\n0 - Any" +
                "\n1 – Refrigerators" +
                "\n2 – Vacuums" +
                "\n3 – Microwaves" +
                "\n4 – Dishwashers" +
                "\nEnter type of appliance:");
            */
            // Get user input as string and assign to appliance type variable

            //string applianceType = Console.ReadLine();

            // Write "Enter number of appliances: "

            Console.WriteLine("Enter number of appliances: ");

            // Get user input as string and assign to variable

            string numOfAppliances = Console.ReadLine();

            // Convert user input from string to int

            int num = int.Parse(numOfAppliances);

            // Create variable to hold list of found appliances

            List<Appliance> found = new List<Appliance>();

            // Loop through appliances
            // Test inputted appliance type is "0"
            // Add current appliance in list to found list


            /*
            foreach (Appliance appliance in Appliances)
            {
                   if (applianceType == "0")
                {
                    found.Add(appliance);
                }
                else if (applianceType == "1" && appliance is Refrigerator)
                {
                    found.Add(appliance);
                }
                else if (applianceType == "2" && appliance is Vacuum)
                {
                    found.Add(appliance);
                }
                else if (applianceType == "3" && appliance is Microwave)
                {
                    found.Add(appliance);
                }
                else if (applianceType == "4" && appliance is Dishwasher)
                {
                    found.Add(appliance);
                }
            }

            */
            // Test inputted appliance type is "1"
            // Test current appliance type is Refrigerator
            // Add current appliance in list to found list
            // Test inputted appliance type is "2"
            // Test current appliance type is Vacuum
            // Add current appliance in list to found list
            // Test inputted appliance type is "3"
            // Test current appliance type is Microwave
            // Add current appliance in list to found list
            // Test inputted appliance type is "4"
            // Test current appliance type is Dishwasher
            // Add current appliance in list to found list

            foreach (Appliance appliance in Appliances)
            {
                found.Add(appliance);
            }

            // Randomize list of found appliances

            found.Sort(new RandomComparer());



            // Display found appliances (up to max. number inputted)
            // DisplayAppliancesFromList(found, num);

            // make for loop that does something num times

            if (found.Count > 0)
            {
                Console.WriteLine("Found Appliances:");
                for (int i = 0; i < num; i++)
                {
                    Console.WriteLine(found[i]);
                }
            }
            else
            {
                Console.WriteLine("No appliances found with the specified type.");
            }
        }
    }
}
